# 1.2.1

Should properly get the TierNum

# 1.2.0

Fixed Null Reference

# 1.1.0

Update for AtO v1.6.22

# 1.0.0

Initial release.
